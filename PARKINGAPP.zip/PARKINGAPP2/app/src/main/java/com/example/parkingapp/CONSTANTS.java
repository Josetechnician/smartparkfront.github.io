package com.example.parkingapp;

public  class CONSTANTS {
   static public int USERID;
   static public  String FULLNAME;
   static public String PHONENO;
   static public String RESERVATIONID;
   static public  String RESERVATIONFEES;
   static public  String UNAME;


}
